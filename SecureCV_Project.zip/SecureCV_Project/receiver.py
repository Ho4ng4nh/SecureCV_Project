import socket
import os
import json
from datetime import datetime
from cryptography.hazmat.primitives import hashes
# Cập nhật import cho padding
from cryptography.hazmat.primitives.asymmetric import padding as asymmetric_padding, rsa
from cryptography.hazmat.primitives import padding as symmetric_padding # Dòng mới
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# Cấu hình IP và Port
HOST = '192.168.100.206'  # Đặt là IP thực của máy Receiver
PORT = 65432        # Port Receiver sẽ lắng nghe

# Đường dẫn đến Public Key của Sender (dùng để xác minh chữ ký)
SENDER_PUBLIC_KEY_PATH = "rsa_keys/public_key.pem"

# Đường dẫn đến Private Key của Receiver (dùng để giải mã Session Key)
RECEIVER_PRIVATE_KEY_PATH = "rsa_keys/private_key.pem"

# Danh sách các IP hợp lệ được phép gửi CV
ALLOWED_SENDER_IPS = ['192.168.100.206'] # Đảm bảo IP của máy Sender có trong đây

def load_public_key(path):
    with open(path, "rb") as key_file:
        public_key = serialization.load_pem_public_key(
            key_file.read(),
            backend=default_backend()
        )
    return public_key

def load_private_key(path):
    with open(path, "rb") as key_file:
        private_key = serialization.load_pem_private_key(
            key_file.read(),
            password=None,
            backend=default_backend()
        )
    return private_key


def start_receiver():
    print(f"[{datetime.now()}] Receiver: Khởi động trên {HOST}:{PORT}")

    try:
        sender_public_key = load_public_key(SENDER_PUBLIC_KEY_PATH)
        print(f"[{datetime.now()}] Receiver: Đã tải Public Key của Sender.")
    except Exception as e:
        print(f"[{datetime.now()}] Lỗi khi tải Public Key của Sender: {e}")
        return

    try:
        receiver_private_key = load_private_key(RECEIVER_PRIVATE_KEY_PATH)
        print(f"[{datetime.now()}] Receiver: Đã tải Private Key của Receiver.")
    except Exception as e:
        print(f"[{datetime.now()}] Lỗi khi tải Private Key của Receiver: {e}")
        return

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print(f"[{datetime.now()}] Receiver: Đang lắng nghe kết nối...")

        conn, addr = s.accept()
        client_ip = addr[0]
        print(f"[{datetime.now()}] Receiver: Đã kết nối từ {client_ip}")

        with conn:
            # --- 1. Handshake ---
            data = conn.recv(1024).decode('utf-8')
            if data.startswith("Hello! IP:"):
                received_ip = data.split("IP:")[1].strip()
                print(f"[{datetime.now()}] Receiver: Nhận được Handshake từ {received_ip}")

                # Kiểm tra IP kết nối có khớp với IP người gửi trong handshake không
                # Và IP có nằm trong danh sách cho phép không
                if received_ip == client_ip and client_ip in ALLOWED_SENDER_IPS:
                    conn.sendall(b"Ready!")
                    print(f"[{datetime.now()}] Receiver: Gửi 'Ready!' đến Sender.")
                else:
                    conn.sendall(b"NACK: Invalid IP or IP mismatch in handshake.")
                    print(f"[{datetime.now()}] Receiver: IP không hợp lệ ({received_ip}) hoặc không khớp ({client_ip}). Gửi NACK và đóng kết nối.")
                    return

                # --- 2. Xác thực & Trao khóa ---
                # Nhận session key đã mã hóa và chữ ký metadata
                encrypted_session_key_len_bytes = conn.recv(4)
                if not encrypted_session_key_len_bytes: # Kiểm tra kết nối đóng
                    print(f"[{datetime.now()}] Receiver: Kết nối bị đóng đột ngột khi nhận độ dài session key.")
                    conn.sendall(b"NACK: Connection closed unexpectedly.")
                    return
                encrypted_session_key_len = int.from_bytes(encrypted_session_key_len_bytes, 'big')
                encrypted_session_key = conn.recv(encrypted_session_key_len)

                signature_len_bytes = conn.recv(4)
                if not signature_len_bytes:
                    print(f"[{datetime.now()}] Receiver: Kết nối bị đóng đột ngột khi nhận độ dài chữ ký.")
                    conn.sendall(b"NACK: Connection closed unexpectedly.")
                    return
                signature_len = int.from_bytes(signature_len_bytes, 'big')
                signature = conn.recv(signature_len)

                metadata_bytes_len_bytes = conn.recv(4)
                if not metadata_bytes_len_bytes:
                    print(f"[{datetime.now()}] Receiver: Kết nối bị đóng đột ngột khi nhận độ dài metadata.")
                    conn.sendall(b"NACK: Connection closed unexpectedly.")
                    return
                metadata_bytes_len = int.from_bytes(metadata_bytes_len_bytes, 'big')
                metadata_bytes = conn.recv(metadata_bytes_len)
                
                # Kiểm tra nếu metadata_bytes rỗng hoặc không phải JSON hợp lệ
                if not metadata_bytes:
                    conn.sendall(b"NACK: Empty metadata received.")
                    print(f"[{datetime.now()}] Receiver: Nhận metadata rỗng. Gửi NACK.")
                    return

                try:
                    metadata = json.loads(metadata_bytes.decode('utf-8'))
                except json.JSONDecodeError as e:
                    conn.sendall(b"NACK: Invalid metadata format.")
                    print(f"[{datetime.now()}] Receiver: Lỗi giải mã JSON metadata: {e}. Gửi NACK.")
                    return


                print(f"[{datetime.now()}] Receiver: Nhận Session Key mã hóa và Chữ ký Metadata.")
                print(f"[{datetime.now()}] Receiver: Metadata nhận được: {metadata}")

                # Kiểm tra IP từ metadata lần nữa (để xác nhận với IP kết nối)
                if metadata.get('ip') != client_ip or client_ip not in ALLOWED_SENDER_IPS:
                    conn.sendall(b"NACK: IP mismatch or not allowed in metadata after handshake.")
                    print(f"[{datetime.now()}] Receiver: IP trong metadata không khớp hoặc không hợp lệ. Gửi NACK.")
                    return

                try:
                    # Xác minh chữ ký của metadata
                    sender_public_key.verify(
                        signature,
                        metadata_bytes,
                        asymmetric_padding.PSS( # Dùng asymmetric_padding
                            mgf=asymmetric_padding.MGF1(hashes.SHA512()),
                            salt_length=asymmetric_padding.PSS.MAX_LENGTH
                        ),
                        hashes.SHA512()
                    )
                    print(f"[{datetime.now()}] Receiver: Xác minh chữ ký Metadata THÀNH CÔNG.")

                    # Giải mã Session Key bằng Private Key của Receiver
                    session_key = receiver_private_key.decrypt(
                        encrypted_session_key,
                        asymmetric_padding.OAEP( # Dùng asymmetric_padding
                            mgf=asymmetric_padding.MGF1(algorithm=hashes.SHA256()), # Đã sửa thành SHA256
                            algorithm=hashes.SHA256(),                   # Đã sửa thành SHA256
                            label=None
                        )
                    )
                    print(f"[{datetime.now()}] Receiver: Giải mã Session Key THÀNH CÔNG.")

                except Exception as e:
                    conn.sendall(b"NACK: Authentication/Decryption Failed.")
                    print(f"[{datetime.now()}] Receiver: Lỗi xác thực hoặc giải mã Session Key: {e}. Gửi NACK.")
                    return

                # --- 3. Nhận Gói tin mã hóa & Kiểm tra toàn vẹn ---
                packet_len_bytes = conn.recv(8)
                if not packet_len_bytes:
                    print(f"[{datetime.now()}] Receiver: Kết nối bị đóng đột ngột khi nhận độ dài gói tin.")
                    conn.sendall(b"NACK: Connection closed unexpectedly.")
                    return
                packet_len = int.from_bytes(packet_len_bytes, 'big')
                print(f"[{datetime.now()}] Receiver: Kích thước gói tin mã hóa dự kiến: {packet_len} bytes.")

                received_packet_bytes = b''
                bytes_received = 0
                while bytes_received < packet_len:
                    chunk = conn.recv(min(4096, packet_len - bytes_received))
                    if not chunk:
                        print(f"[{datetime.now()}] Receiver: Kết nối bị đóng đột ngột khi nhận gói tin dữ liệu.")
                        conn.sendall(b"NACK: Connection closed unexpectedly during data transfer.")
                        return
                    received_packet_bytes += chunk
                    bytes_received += len(chunk)
                
                # Kiểm tra nếu received_packet_bytes rỗng hoặc không phải JSON hợp lệ
                if not received_packet_bytes:
                    conn.sendall(b"NACK: Empty encrypted packet received.")
                    print(f"[{datetime.now()}] Receiver: Nhận gói tin mã hóa rỗng. Gửi NACK.")
                    return
                
                try:
                    received_packet = json.loads(received_packet_bytes.decode('utf-8'))
                except json.JSONDecodeError as e:
                    conn.sendall(b"NACK: Invalid encrypted packet format.")
                    print(f"[{datetime.now()}] Receiver: Lỗi giải mã JSON gói tin mã hóa: {e}. Gửi NACK.")
                    return


                iv = bytes.fromhex(received_packet['iv'])
                ciphertext = bytes.fromhex(received_packet['cipher'])
                received_hash = bytes.fromhex(received_packet['hash'])

                print(f"[{datetime.now()}] Receiver: Đã nhận IV, Ciphertext và Hash.")

                # Kiểm tra tính toàn vẹn (hash)
                calculated_hash = hashes.Hash(hashes.SHA512(), backend=default_backend())
                calculated_hash.update(iv + ciphertext)
                computed_hash = calculated_hash.finalize()

                if computed_hash == received_hash:
                    print(f"[{datetime.now()}] Receiver: Kiểm tra tính toàn vẹn (Hash) THÀNH CÔNG.")

                    # Giải mã ciphertext
                    cipher = Cipher(algorithms.AES(session_key), modes.CBC(iv), backend=default_backend())
                    decryptor = cipher.decryptor()
                    decrypted_data = decryptor.update(ciphertext) + decryptor.finalize()

                    # Loại bỏ padding PKCS7
                    unpadder = symmetric_padding.PKCS7(algorithms.AES.block_size).unpadder() # Đã sửa thành symmetric_padding
                    original_data = unpadder.update(decrypted_data) + unpadder.finalize()

                    # Lưu file CV
                    output_filename = f"received_cv_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                    with open(output_filename, "wb") as f:
                        f.write(original_data)
                    print(f"[{datetime.now()}] Receiver: Giải mã và lưu file CV thành công: {output_filename}")
                    conn.sendall(b"ACK: CV received and processed successfully.")
                else:
                    conn.sendall(b"NACK: Integrity check failed.")
                    print(f"[{datetime.now()}] Receiver: KIỂM TRA TÍNH TOÀN VẸN (Hash) THẤT BẠI. Gửi NACK.")

            else:
                conn.sendall(b"NACK: Invalid Handshake.")
                print(f"[{datetime.now()}] Receiver: Handshake không hợp lệ. Gửi NACK.")

if __name__ == "__main__":
    start_receiver()