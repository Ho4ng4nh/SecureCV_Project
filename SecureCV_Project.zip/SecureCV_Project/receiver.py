import tkinter as tk
from tkinter import scrolledtext, messagebox
import socket
import os
import json
import threading
from datetime import datetime
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding as asymmetric_padding, rsa
from cryptography.hazmat.primitives import padding as symmetric_padding
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# --- Cấu hình chung ---
# Đặt HOST là '0.0.0.0' để Receiver lắng nghe trên tất cả các địa chỉ IP của máy này.
# Đây là cách đáng tin cậy nhất để tránh lỗi binding IP.
HOST = '0.0.0.0'
PORT = 65432

# Đường dẫn đến Public Key của Sender (dùng để xác minh chữ ký)
SENDER_PUBLIC_KEY_PATH = "rsa_keys/public_key.pem"
# Đường dẫn đến Private Key của Receiver (dùng để giải mã Session Key)
RECEIVER_PRIVATE_KEY_PATH = "rsa_keys/private_key.pem"

# Danh sách các IP hợp lệ được phép gửi CV
# Đây là IP thực của máy Sender của bạn (từ ipconfig của máy Sender)
ALLOWED_SENDER_IPS = ['192.168.100.206']
# Nếu bạn cũng muốn cho phép localhost (127.0.0.1) cho các thử nghiệm cục bộ,
# bạn có thể thêm vào: ALLOWED_SENDER_IPS = ['127.0.0.1', '192.168.100.206']

# --- Hàm hỗ trợ mật mã (tích hợp từ receiver.py cũ) ---
def load_public_key(path):
    with open(path, "rb") as key_file:
        public_key = serialization.load_pem_public_key(
            key_file.read(),
            backend=default_backend()
        )
    return public_key

def load_private_key(path):
    with open(path, "rb") as key_file:
        private_key = serialization.load_pem_private_key(
            key_file.read(),
            password=None,
            backend=default_backend()
        )
    return private_key

# --- Logic xử lý kết nối chính (chạy trong một luồng riêng) ---
def handle_client_connection(conn, addr, log_widget, sender_public_key, receiver_private_key):
    client_ip = addr[0]
    log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Đã kết nối từ {client_ip}\n")
    log_widget.see(tk.END)

    try:
        # --- 1. Handshake ---
        data = conn.recv(1024).decode('utf-8')
        if not data.startswith("Hello! IP:"):
            conn.sendall(b"NACK: Invalid Handshake.")
            log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Handshake không hợp lệ. Gửi NACK.\n")
            return

        received_ip = data.split("IP:")[1].strip()
        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Nhận được Handshake từ {received_ip}\n")

        # Kiểm tra IP kết nối có khớp với IP người gửi trong handshake
        # VÀ IP có nằm trong danh sách cho phép
        # Hoặc chấp nhận nếu client_ip là localhost và received_ip hợp lệ
        if (received_ip == client_ip and client_ip in ALLOWED_SENDER_IPS) or \
           (client_ip == '127.0.0.1' and received_ip in ALLOWED_SENDER_IPS and '127.0.0.1' in ALLOWED_SENDER_IPS):
            conn.sendall(b"Ready!")
            log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Gửi 'Ready!' đến Sender.\n")
        else:
            conn.sendall(b"NACK: Invalid IP or IP mismatch in handshake.")
            log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: IP không hợp lệ ({received_ip}) hoặc không khớp ({client_ip}). Gửi NACK.\n")
            return

        # --- 2. Xác thực & Trao khóa ---
        encrypted_session_key_len_bytes = conn.recv(4)
        if not encrypted_session_key_len_bytes: raise Exception("Kết nối bị đóng đột ngột khi nhận độ dài session key.")
        encrypted_session_key_len = int.from_bytes(encrypted_session_key_len_bytes, 'big')
        encrypted_session_key = conn.recv(encrypted_session_key_len)

        signature_len_bytes = conn.recv(4)
        if not signature_len_bytes: raise Exception("Kết nối bị đóng đột ngột khi nhận độ dài chữ ký.")
        signature_len = int.from_bytes(signature_len_bytes, 'big')
        signature = conn.recv(signature_len)

        metadata_bytes_len_bytes = conn.recv(4)
        if not metadata_bytes_len_bytes: raise Exception("Kết nối bị đóng đột ngột khi nhận độ dài metadata.")
        metadata_bytes_len = int.from_bytes(metadata_bytes_len_bytes, 'big')
        metadata_bytes = conn.recv(metadata_bytes_len)
        
        if not metadata_bytes: raise Exception("Nhận metadata rỗng.")

        try:
            metadata = json.loads(metadata_bytes.decode('utf-8'))
        except json.JSONDecodeError as e:
            raise Exception(f"Lỗi giải mã JSON metadata: {e}.")

        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Nhận Session Key mã hóa và Chữ ký Metadata.\n")
        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Metadata nhận được: {metadata}\n")

        # Kiểm tra IP từ metadata lần nữa
        if not (metadata.get('ip') in ALLOWED_SENDER_IPS and \
                (metadata.get('ip') == client_ip or client_ip == '127.0.0.1')):
            conn.sendall(b"NACK: IP mismatch or not allowed in metadata after handshake.")
            log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: IP trong metadata không khớp hoặc không hợp lệ. Gửi NACK.\n")
            return

        # Xác minh chữ ký của metadata
        sender_public_key.verify(
            signature,
            metadata_bytes,
            asymmetric_padding.PSS(
                mgf=asymmetric_padding.MGF1(hashes.SHA512()),
                salt_length=asymmetric_padding.PSS.MAX_LENGTH
            ),
            hashes.SHA512()
        )
        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Xác minh chữ ký Metadata THÀNH CÔNG.\n")

        # Giải mã Session Key bằng Private Key của Receiver
        session_key = receiver_private_key.decrypt(
            encrypted_session_key,
            asymmetric_padding.OAEP(
                mgf=asymmetric_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Giải mã Session Key THÀNH CÔNG.\n")

        # --- 3. Nhận Gói tin mã hóa & Kiểm tra toàn vẹn ---
        packet_len_bytes = conn.recv(8)
        if not packet_len_bytes: raise Exception("Kết nối bị đóng đột ngột khi nhận độ dài gói tin.")
        packet_len = int.from_bytes(packet_len_bytes, 'big')
        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Kích thước gói tin mã hóa dự kiến: {packet_len} bytes.\n")

        received_packet_bytes = b''
        bytes_received = 0
        while bytes_received < packet_len:
            chunk = conn.recv(min(4096, packet_len - bytes_received))
            if not chunk: raise Exception("Kết nối bị đóng đột ngột khi nhận gói tin dữ liệu.")
            received_packet_bytes += chunk
            bytes_received += len(chunk)
        
        if not received_packet_bytes: raise Exception("Nhận gói tin mã hóa rỗng.")
        
        try:
            received_packet = json.loads(received_packet_bytes.decode('utf-8'))
        except json.JSONDecodeError as e:
            raise Exception(f"Lỗi giải mã JSON gói tin mã hóa: {e}.")

        iv = bytes.fromhex(received_packet['iv'])
        ciphertext = bytes.fromhex(received_packet['cipher'])
        received_hash = bytes.fromhex(received_packet['hash'])

        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Đã nhận IV, Ciphertext và Hash.\n")

        # Kiểm tra tính toàn vẹn (hash)
        calculated_hash = hashes.Hash(hashes.SHA512(), backend=default_backend())
        calculated_hash.update(iv + ciphertext)
        computed_hash = calculated_hash.finalize()

        if computed_hash == received_hash:
            log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Kiểm tra tính toàn vẹn (Hash) THÀNH CÔNG.\n")

            # Giải mã ciphertext
            cipher = Cipher(algorithms.AES(session_key), modes.CBC(iv), backend=default_backend())
            decryptor = cipher.decryptor()
            decrypted_data = decryptor.update(ciphertext) + decryptor.finalize()

            # Loại bỏ padding PKCS7
            unpadder = symmetric_padding.PKCS7(algorithms.AES.block_size).unpadder()
            original_data = unpadder.update(decrypted_data) + unpadder.finalize()

            # Lưu file CV
            output_filename = f"received_cv_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
            with open(output_filename, "wb") as f:
                f.write(original_data)
            log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Giải mã và lưu file CV thành công: {output_filename}\n")
            conn.sendall(b"ACK: CV received and processed successfully.")
            messagebox.showinfo("Thành công", f"File '{metadata.get('file_name', 'CV')}' đã được nhận và lưu thành công!")
        else:
            conn.sendall(b"NACK: Integrity check failed.")
            log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: KIỂM TRA TÍNH TOÀN VẸN (Hash) THẤT BẠI. Gửi NACK.\n")
            messagebox.showerror("Thất bại", "Kiểm tra tính toàn vẹn (Hash) thất bại.")

    except Exception as e:
        log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi xử lý kết nối: {e}\n")
        conn.sendall(f"NACK: Lỗi xử lý ({e})".encode('utf-8'))
    finally:
        conn.close()
        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Kết nối với {client_ip} đã đóng.\n")
        log_widget.see(tk.END)


# --- Lắng nghe kết nối trong luồng riêng ---
def start_listening(log_widget):
    log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Đang khởi động...\n")
    try:
        sender_public_key = load_public_key(SENDER_PUBLIC_KEY_PATH)
        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Đã tải Public Key của Sender.\n")
    except Exception as e:
        log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi: Không tải được Public Key của Sender: {e}\n")
        return

    try:
        receiver_private_key = load_private_key(RECEIVER_PRIVATE_KEY_PATH)
        log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Đã tải Private Key của Receiver.\n")
    except Exception as e:
        log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi: Không tải được Private Key của Receiver: {e}\n")
        return

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((HOST, PORT))
            s.listen()
            log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Đang lắng nghe kết nối trên {HOST}:{PORT}...\n")
            log_widget.see(tk.END)

            while True: # Vòng lặp để chấp nhận nhiều kết nối
                conn, addr = s.accept()
                log_widget.insert(tk.END, f"[{datetime.now()}] Receiver: Đã nhận kết nối mới. Bắt đầu xử lý trong luồng riêng.\n")
                log_widget.see(tk.END)
                # Xử lý mỗi kết nối trong một luồng riêng
                threading.Thread(target=handle_client_connection, args=(conn, addr, log_widget, sender_public_key, receiver_private_key)).start()
    except Exception as e:
        log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi khi khởi động Receiver: {e}\n")
        messagebox.showerror("Lỗi khởi động", f"Không thể khởi động Receiver: {e}")
    finally:
        log_widget.see(tk.END)

# --- Giao diện Tkinter ---
class ReceiverGUI:
    def __init__(self, master):
        self.master = master
        master.title("Ứng dụng Nhận CV An toàn")

        main_frame = tk.Frame(master, padx=10, pady=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(main_frame, text=f"Receiver đang lắng nghe trên {HOST}:{PORT}").pack(pady=5)
        
        tk.Label(main_frame, text="Log Hoạt Động:").pack(pady=5, anchor=tk.W)
        self.log_text = scrolledtext.ScrolledText(main_frame, width=80, height=25, wrap=tk.WORD, state=tk.DISABLED)
        self.log_text.pack(fill=tk.BOTH, expand=True)

        # Chạy hàm lắng nghe kết nối trong một luồng riêng
        self.listen_thread = threading.Thread(target=start_listening, args=(self.log_text,))
        self.listen_thread.daemon = True # Đặt luồng là daemon để nó tự dừng khi ứng dụng chính đóng
        self.listen_thread.start()

        # Cấu hình để cuộn log tự động
        self.log_text.bind("<Key>", lambda e: "break") # Ngăn người dùng chỉnh sửa log

if __name__ == "__main__":
    root = tk.Tk()
    app = ReceiverGUI(root)
    root.geometry("700x700") # Kích thước cửa sổ mặc định
    root.mainloop()