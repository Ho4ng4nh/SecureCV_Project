import socket
import os
import json
import time
from datetime import datetime
from cryptography.hazmat.primitives import hashes
# Đảm bảo import đúng cho cả padding bất đối xứng và đối xứng
from cryptography.hazmat.primitives.asymmetric import padding as asymmetric_padding, rsa
from cryptography.hazmat.primitives import padding as symmetric_padding
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# Cấu hình IP và Port của Receiver
# Đặt là IP thực của máy bạn (nơi cả Sender và Receiver đang chạy)
HOST = '192.168.100.206'
PORT = 65432        # Port của Receiver (đặt cùng với PORT trong receiver.py)

# Đường dẫn đến Public Key của Receiver (dùng để mã hóa Session Key)
RECEIVER_PUBLIC_KEY_PATH = "rsa_keys/public_key.pem"

# Đường dẫn đến Private Key của Sender (dùng để ký metadata)
SENDER_PRIVATE_KEY_PATH = "rsa_keys/private_key.pem"

# File CV cần gửi
CV_FILE_PATH = "cv.pdf" # Đảm bảo file này có trong cùng thư mục với sender.py

def load_private_key(path):
    with open(path, "rb") as key_file:
        private_key = serialization.load_pem_private_key(
            key_file.read(),
            password=None, # Đặt mật khẩu nếu bạn đã mã hóa private key khi tạo
            backend=default_backend()
        )
    return private_key

def load_public_key(path):
    with open(path, "rb") as key_file:
        public_key = serialization.load_pem_public_key(
            key_file.read(),
            backend=default_backend()
        )
    return public_key

def get_my_ip():
    # Cách đơn giản để lấy IP cục bộ của Sender
    # Sẽ trả về IP thực của card mạng (ví dụ: 192.168.100.206)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)) # Kết nối đến một địa chỉ ngoài để lấy IP của chính mình
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return HOST # Trả về HOST mặc định nếu không lấy được (ví dụ: đang offline)

def start_sender():
    print(f"[{datetime.now()}] Sender: Đang cố gắng kết nối đến Receiver tại {HOST}:{PORT}")
    current_ip = get_my_ip()
    print(f"[{datetime.now()}] Sender: IP hiện tại của tôi: {current_ip}")

    # Load Private Key của Sender
    try:
        sender_private_key = load_private_key(SENDER_PRIVATE_KEY_PATH)
        print(f"[{datetime.now()}] Sender: Đã tải Private Key của Sender.")
    except FileNotFoundError:
        print(f"[{datetime.now()}] Lỗi: Không tìm thấy Private Key của Sender tại {SENDER_PRIVATE_KEY_PATH}. Vui lòng tạo khóa trước.")
        return
    except Exception as e:
        print(f"[{datetime.now()}] Lỗi khi tải Private Key của Sender: {e}")
        return

    # Load Public Key của Receiver
    try:
        receiver_public_key = load_public_key(RECEIVER_PUBLIC_KEY_PATH)
        print(f"[{datetime.now()}] Sender: Đã tải Public Key của Receiver.")
    except FileNotFoundError:
        print(f"[{datetime.now()}] Lỗi: Không tìm thấy Public Key của Receiver tại {RECEIVER_PUBLIC_KEY_PATH}. Vui lòng tạo khóa trước.")
        return
    except Exception as e:
        print(f"[{datetime.now()}] Lỗi khi tải Public Key của Receiver: {e}")
        return

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((HOST, PORT))
            print(f"[{datetime.now()}] Sender: Đã kết nối đến Receiver.")

            # --- 1. Handshake ---
            handshake_msg = f"Hello! IP: {current_ip}"
            s.sendall(handshake_msg.encode('utf-8'))
            print(f"[{datetime.now()}] Sender: Gửi Handshake: '{handshake_msg}'")

            response = s.recv(1024).decode('utf-8')
            if response == "Ready!":
                print(f"[{datetime.now()}] Sender: Nhận phản hồi 'Ready!' từ Receiver. Bắt đầu trao đổi khóa.")
            elif response.startswith("NACK:"):
                print(f"[{datetime.now()}] Sender: Receiver từ chối: {response}. Đóng kết nối.")
                return
            else:
                print(f"[{datetime.now()}] Sender: Phản hồi không mong muốn từ Receiver: {response}. Đóng kết nối.")
                return

            # --- 2. Xác thực & Trao khóa ---
            # Tạo Session Key (khóa AES)
            session_key = os.urandom(32)  # 256-bit key for AES
            print(f"[{datetime.now()}] Sender: Đã tạo Session Key AES.")

            # Metadata để ký
            file_name = os.path.basename(CV_FILE_PATH)
            timestamp = datetime.now().isoformat()
            metadata = {
                "file_name": file_name,
                "timestamp": timestamp,
                "ip": current_ip,
                "size": os.path.getsize(CV_FILE_PATH)
            }
            metadata_bytes = json.dumps(metadata).encode('utf-8')
            print(f"[{datetime.now()}] Sender: Metadata: {metadata}")

            # Ký metadata bằng Private Key của Sender
            signature = sender_private_key.sign(
                metadata_bytes,
                asymmetric_padding.PSS( # Dùng asymmetric_padding
                    mgf=asymmetric_padding.MGF1(hashes.SHA512()),
                    salt_length=asymmetric_padding.PSS.MAX_LENGTH
                ),
                hashes.SHA512()
            )
            print(f"[{datetime.now()}] Sender: Đã ký metadata.")

            # Mã hóa Session Key bằng Public Key của Receiver (OAEP)
            encrypted_session_key = receiver_public_key.encrypt(
                session_key,
                asymmetric_padding.OAEP( # Dùng asymmetric_padding
                    mgf=asymmetric_padding.MGF1(algorithm=hashes.SHA256()), # Đã sửa thành SHA256
                    algorithm=hashes.SHA256(),                   # Đã sửa thành SHA256
                    label=None
                )
            )
            print(f"[{datetime.now()}] Sender: Đã mã hóa Session Key bằng Public Key của Receiver.")

            # Gửi session key đã mã hóa, chữ ký và metadata
            s.sendall(len(encrypted_session_key).to_bytes(4, 'big')) # Gửi độ dài
            s.sendall(encrypted_session_key)

            s.sendall(len(signature).to_bytes(4, 'big')) # Gửi độ dài
            s.sendall(signature)

            s.sendall(len(metadata_bytes).to_bytes(4, 'big')) # Gửi độ dài
            s.sendall(metadata_bytes)
            print(f"[{datetime.now()}] Sender: Đã gửi Session Key mã hóa, chữ ký và metadata.")

            # --- 3. Mã hóa & Kiểm tra toàn vẹn ---
            # Đọc file CV
            try:
                with open(CV_FILE_PATH, "rb") as f:
                    file_data = f.read()
                print(f"[{datetime.now()}] Sender: Đã đọc file CV: {CV_FILE_PATH}")
            except FileNotFoundError:
                print(f"[{datetime.now()}] Lỗi: Không tìm thấy file CV tại {CV_FILE_PATH}.")
                return

            # Tạo IV (Initialization Vector)
            iv = os.urandom(16) # 128-bit IV for AES-CBC
            print(f"[{datetime.now()}] Sender: Đã tạo IV.")

            # Padding dữ liệu trước khi mã hóa (AES-CBC yêu cầu dữ liệu có độ dài là bội số của block_size)
            padder = symmetric_padding.PKCS7(algorithms.AES.block_size).padder() # Dùng symmetric_padding
            padded_data = padder.update(file_data) + padder.finalize()

            # Mã hóa file bằng AES-CBC
            cipher = Cipher(algorithms.AES(session_key), modes.CBC(iv), backend=default_backend())
            encryptor = cipher.encryptor()
            ciphertext = encryptor.update(padded_data) + encryptor.finalize()
            print(f"[{datetime.now()}] Sender: Đã mã hóa file CV bằng AES-CBC.")

            # Tính hash: SHA-512(IV || ciphertext)
            hasher = hashes.Hash(hashes.SHA512(), backend=default_backend())
            hasher.update(iv + ciphertext)
            calculated_hash = hasher.finalize()
            print(f"[{datetime.now()}] Sender: Đã tính toán hash của (IV || Ciphertext).")

            # Gói tin gửi
            packet = {
                "iv": iv.hex(),
                "cipher": ciphertext.hex(),
                "hash": calculated_hash.hex(),
                "sig": signature.hex() # Chữ ký của metadata, được chuyển đổi thành hex
            }
            packet_json = json.dumps(packet)
            packet_bytes = packet_json.encode('utf-8')

            # Gửi độ dài của gói tin trước, sau đó gửi gói tin
            s.sendall(len(packet_bytes).to_bytes(8, 'big')) # Gửi 8 bytes cho độ dài gói tin
            s.sendall(packet_bytes)
            print(f"[{datetime.now()}] Sender: Đã gửi gói tin mã hóa đến Receiver.")

            # --- 4. Nhận ACK/NACK từ Receiver ---
            final_response = s.recv(1024).decode('utf-8')
            if final_response.startswith("ACK:"):
                print(f"[{datetime.now()}] Sender: Nhận ACK: {final_response}. CV đã được gửi thành công.")
            elif final_response.startswith("NACK:"):
                print(f"[{datetime.now()}] Sender: Nhận NACK: {final_response}. Gửi CV thất bại.")
            else:
                print(f"[{datetime.now()}] Sender: Phản hồi không mong muốn sau khi gửi gói tin: {final_response}")

    except ConnectionRefusedError:
        print(f"[{datetime.now()}] Lỗi: Kết nối bị từ chối. Đảm bảo Receiver đang chạy và lắng nghe trên {HOST}:{PORT}.")
    except FileNotFoundError as e:
        print(f"[{datetime.now()}] Lỗi: Một trong các file khóa hoặc file CV không tìm thấy: {e}.")
    except Exception as e:
        print(f"[{datetime.now()}] Lỗi không xác định: {e}")

if __name__ == "__main__":
    start_sender()