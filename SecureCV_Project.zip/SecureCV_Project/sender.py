import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import socket
import os
import json
import time
from datetime import datetime
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding as asymmetric_padding, rsa
from cryptography.hazmat.primitives import padding as symmetric_padding
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# --- Cấu hình chung ---
# Đường dẫn đến Public Key của Receiver (dùng để mã hóa Session Key)
RECEIVER_PUBLIC_KEY_PATH = "rsa_keys/public_key.pem"
# Đường dẫn đến Private Key của Sender (dùng để ký metadata)
SENDER_PRIVATE_KEY_PATH = "rsa_keys/private_key.pem"

# --- Hàm hỗ trợ mã hóa/ký số (tích hợp từ sender.py cũ) ---
def load_private_key(path):
    with open(path, "rb") as key_file:
        private_key = serialization.load_pem_private_key(
            key_file.read(),
            password=None,
            backend=default_backend()
        )
    return private_key

def load_public_key(path):
    with open(path, "rb") as key_file:
        public_key = serialization.load_pem_public_key(
            key_file.read(),
            backend=default_backend()
        )
    return public_key

def get_my_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1' # Fallback an toàn nếu không lấy được IP thực

# --- Hàm gửi file chính (tích hợp và điều chỉnh từ start_sender) ---
def send_file_securely(receiver_host, receiver_port, cv_filepath, log_widget):
    log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đang cố gắng kết nối đến Receiver tại {receiver_host}:{receiver_port}\n")
    current_ip = get_my_ip()
    log_widget.insert(tk.END, f"[{datetime.now()}] Sender: IP hiện tại của tôi: {current_ip}\n")
    log_widget.see(tk.END) # Cuộn xuống cuối

    # Load Private Key của Sender
    try:
        sender_private_key = load_private_key(SENDER_PRIVATE_KEY_PATH)
        log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã tải Private Key của Sender.\n")
    except Exception as e:
        log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi: Không tải được Private Key của Sender: {e}\n")
        return False

    # Load Public Key của Receiver
    try:
        receiver_public_key = load_public_key(RECEIVER_PUBLIC_KEY_PATH)
        log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã tải Public Key của Receiver.\n")
    except Exception as e:
        log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi: Không tải được Public Key của Receiver: {e}\n")
        return False

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((receiver_host, receiver_port))
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã kết nối đến Receiver.\n")

            # --- 1. Handshake ---
            handshake_msg = f"Hello! IP: {current_ip}"
            s.sendall(handshake_msg.encode('utf-8'))
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Gửi Handshake: '{handshake_msg}'\n")

            response = s.recv(1024).decode('utf-8')
            if response.startswith("Ready!"):
                log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Nhận phản hồi 'Ready!' từ Receiver. Bắt đầu trao đổi khóa.\n")
            elif response.startswith("NACK:"):
                log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Receiver từ chối: {response}. Đóng kết nối.\n")
                return False
            else:
                log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Phản hồi không mong muốn từ Receiver: {response}. Đóng kết nối.\n")
                return False

            # --- 2. Xác thực & Trao khóa ---
            session_key = os.urandom(32)
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã tạo Session Key AES.\n")

            file_name = os.path.basename(cv_filepath)
            timestamp = datetime.now().isoformat()
            metadata = {
                "file_name": file_name,
                "timestamp": timestamp,
                "ip": current_ip,
                "size": os.path.getsize(cv_filepath)
            }
            metadata_bytes = json.dumps(metadata).encode('utf-8')
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Metadata: {metadata}\n")

            signature = sender_private_key.sign(
                metadata_bytes,
                asymmetric_padding.PSS(
                    mgf=asymmetric_padding.MGF1(hashes.SHA512()),
                    salt_length=asymmetric_padding.PSS.MAX_LENGTH
                ),
                hashes.SHA512()
            )
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã ký metadata.\n")

            encrypted_session_key = receiver_public_key.encrypt(
                session_key,
                asymmetric_padding.OAEP(
                    mgf=asymmetric_padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã mã hóa Session Key bằng Public Key của Receiver.\n")

            s.sendall(len(encrypted_session_key).to_bytes(4, 'big'))
            s.sendall(encrypted_session_key)
            s.sendall(len(signature).to_bytes(4, 'big'))
            s.sendall(signature)
            s.sendall(len(metadata_bytes).to_bytes(4, 'big'))
            s.sendall(metadata_bytes)
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã gửi Session Key mã hóa, chữ ký và metadata.\n")

            # --- 3. Mã hóa & Kiểm tra toàn vẹn ---
            try:
                with open(cv_filepath, "rb") as f:
                    file_data = f.read()
                log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã đọc file CV: {cv_filepath}\n")
            except FileNotFoundError:
                log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi: Không tìm thấy file CV tại {cv_filepath}.\n")
                return False

            iv = os.urandom(16)
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã tạo IV.\n")

            padder = symmetric_padding.PKCS7(algorithms.AES.block_size).padder()
            padded_data = padder.update(file_data) + padder.finalize()

            cipher = Cipher(algorithms.AES(session_key), modes.CBC(iv), backend=default_backend())
            encryptor = cipher.encryptor()
            ciphertext = encryptor.update(padded_data) + encryptor.finalize()
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã mã hóa file CV bằng AES-CBC.\n")

            hasher = hashes.Hash(hashes.SHA512(), backend=default_backend())
            hasher.update(iv + ciphertext)
            calculated_hash = hasher.finalize()
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã tính toán hash của (IV || Ciphertext).\n")

            packet = {
                "iv": iv.hex(),
                "cipher": ciphertext.hex(),
                "hash": calculated_hash.hex(),
                "sig": signature.hex()
            }
            packet_json = json.dumps(packet)
            packet_bytes = packet_json.encode('utf-8')

            s.sendall(len(packet_bytes).to_bytes(8, 'big'))
            s.sendall(packet_bytes)
            log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Đã gửi gói tin mã hóa đến Receiver.\n")

            # --- 4. Nhận ACK/NACK từ Receiver ---
            final_response = s.recv(1024).decode('utf-8')
            if final_response.startswith("ACK:"):
                log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Nhận ACK: {final_response}. CV đã được gửi thành công.\n")
                messagebox.showinfo("Thành công", "CV đã được gửi thành công!")
                return True
            elif final_response.startswith("NACK:"):
                log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Nhận NACK: {final_response}. Gửi CV thất bại.\n")
                messagebox.showerror("Thất bại", f"Gửi CV thất bại: {final_response}")
                return False
            else:
                log_widget.insert(tk.END, f"[{datetime.now()}] Sender: Phản hồi không mong muốn từ Receiver: {final_response}.\n")
                messagebox.showerror("Lỗi", f"Phản hồi không mong muốn: {final_response}")
                return False

    except ConnectionRefusedError:
        log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi: Kết nối bị từ chối. Đảm bảo Receiver đang chạy và lắng nghe trên {receiver_host}:{receiver_port}.\n")
        messagebox.showerror("Lỗi kết nối", "Kết nối bị từ chối. Đảm bảo Receiver đang chạy và lắng nghe đúng IP/Port.")
        return False
    except FileNotFoundError as e:
        log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi: Một trong các file khóa hoặc file CV không tìm thấy: {e}.\n")
        messagebox.showerror("Lỗi file", f"Lỗi file: {e}")
        return False
    except Exception as e:
        log_widget.insert(tk.END, f"[{datetime.now()}] Lỗi không xác định: {e}\n")
        messagebox.showerror("Lỗi", f"Lỗi không xác định trong quá trình gửi: {e}")
        return False
    finally:
        log_widget.see(tk.END) # Đảm bảo cuộn xuống cuối sau khi hoàn tất

# --- Giao diện Tkinter ---
class SenderGUI:
    def __init__(self, master):
        self.master = master
        master.title("Ứng dụng Gửi CV An toàn")

        self.receiver_host_var = tk.StringVar(value="192.168.100.237") # IP Receiver mặc định
        self.receiver_port_var = tk.IntVar(value=65432) # Port Receiver mặc định
        self.cv_filepath_var = tk.StringVar()

        # Tạo frame chính
        main_frame = tk.Frame(master, padx=10, pady=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Cấu hình lưới cho main_frame
        main_frame.grid_columnconfigure(1, weight=1)

        # Hàng 1: IP của Receiver
        tk.Label(main_frame, text="IP của Receiver:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.ip_entry = tk.Entry(main_frame, textvariable=self.receiver_host_var, width=40)
        self.ip_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5)

        # Hàng 2: Port của Receiver
        tk.Label(main_frame, text="Port của Receiver:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.port_entry = tk.Entry(main_frame, textvariable=self.receiver_port_var, width=40)
        self.port_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5)

        # Hàng 3: Chọn File CV
        tk.Label(main_frame, text="File CV:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.file_label = tk.Label(main_frame, textvariable=self.cv_filepath_var, anchor=tk.W, wraplength=350, justify=tk.LEFT)
        self.file_label.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5)
        self.select_button = tk.Button(main_frame, text="Chọn File CV", command=self.select_cv_file)
        self.select_button.grid(row=3, column=0, columnspan=2, pady=10)

        # Hàng 4: Nút Gửi
        self.send_button = tk.Button(main_frame, text="Gửi CV An Toàn", command=self.send_cv)
        self.send_button.grid(row=4, column=0, columnspan=2, pady=20)

        # Hàng 5: Vùng log
        tk.Label(main_frame, text="Log:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.log_text = scrolledtext.ScrolledText(main_frame, width=60, height=15, wrap=tk.WORD, state=tk.DISABLED)
        self.log_text.grid(row=6, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Cấu hình hàng cho phép vùng log mở rộng
        main_frame.grid_rowconfigure(6, weight=1)

        # Đặt giá trị mặc định cho filepath để tiện test
        # self.cv_filepath_var.set("cv.pdf") # Bỏ comment nếu muốn mặc định là cv.pdf

    def select_cv_file(self):
        filepath = filedialog.askopenfilename(
            title="Chọn file CV (.pdf)",
            filetypes=(("PDF files", "*.pdf"), ("All files", "*.*"))
        )
        if filepath:
            self.cv_filepath_var.set(filepath)

    def send_cv(self):
        receiver_host = self.receiver_host_var.get()
        receiver_port = self.receiver_port_var.get()
        cv_filepath = self.cv_filepath_var.get()

        # Kiểm tra đầu vào
        if not receiver_host:
            messagebox.showerror("Lỗi", "Vui lòng nhập IP của Receiver.")
            return
        if not cv_filepath:
            messagebox.showerror("Lỗi", "Vui lòng chọn file CV.")
            return
        if not os.path.exists(cv_filepath):
            messagebox.showerror("Lỗi", f"File '{cv_filepath}' không tồn tại. Vui lòng chọn lại.")
            return

        # Xóa log cũ
        self.log_text.config(state=tk.NORMAL)
        self.log_text.delete(1.0, tk.END)
        self.log_text.config(state=tk.DISABLED)

        # Gọi hàm gửi file chính.
        # Hàm này sẽ ghi log trực tiếp vào self.log_text
        # Chúng ta chạy nó trong một luồng (thread) riêng để tránh làm đơ giao diện
        import threading
        send_thread = threading.Thread(target=send_file_securely, args=(receiver_host, receiver_port, cv_filepath, self.log_text))
        send_thread.start()


if __name__ == "__main__":
    root = tk.Tk()
    app = SenderGUI(root)
    root.geometry("600x600") # Kích thước cửa sổ mặc định
    root.mainloop()