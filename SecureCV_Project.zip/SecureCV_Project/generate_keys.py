from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

def generate_rsa_keys():
    # Tạo khóa riêng tư RSA 1024-bit
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=1024,
    )

    # Lưu khóa riêng tư vào file
    # Mã hóa khóa riêng tư bằng AES256-CBC với mật khẩu (có thể bỏ qua nếu không cần mật khẩu)
    # Ví dụ này không đặt mật khẩu để đơn giản
    pem_private = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption() # Có thể dùng serialization.BestAvailableEncryption(b'your_strong_password')
    )

    # Lưu khóa công khai vào file
    public_key = private_key.public_key()
    pem_public = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    # Tạo thư mục rsa_keys nếu chưa có
    import os
    if not os.path.exists("rsa_keys"):
        os.makedirs("rsa_keys")

    with open("rsa_keys/private_key.pem", "wb") as f:
        f.write(pem_private)
    with open("rsa_keys/public_key.pem", "wb") as f:
        f.write(pem_public)

    print("Cặp khóa RSA đã được tạo thành công trong thư mục 'rsa_keys/'.")
    print("Khóa riêng tư: private_key.pem")
    print("Khóa công khai: public_key.pem")

if __name__ == "__main__":
    generate_rsa_keys()